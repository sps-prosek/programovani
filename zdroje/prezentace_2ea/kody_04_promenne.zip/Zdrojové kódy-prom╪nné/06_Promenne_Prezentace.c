/*---- | 04 PROMĚNNÉ A DATOVÉ TYPY V C | ----
==============================================
Zdrojový kód: 06_Promenne_Prezentace
*/

#include <stdio.h>  // Zahrnujeme standardní knihovnu pro vstup a výstup. Tato knihovna obsahuje funkce jako printf (pro výstup na obrazovku) a scanf (pro čtení vstupu od uživatele).

int main()  // Hlavní funkce programu, kde začíná vykonávání programu.
{
    int uzivatelsky_vstup;  // Deklarujeme proměnnou typu int (celé číslo) s názvem uzivatelsky_vstup, která bude uchovávat číslo zadané uživatelem.

    printf("Vlozte cislo k zdvojnasobeni: \n");  // Vypisuje zprávu na obrazovku, která vyzývá uživatele, aby zadal číslo, které bude zdvojnásobeno.

    scanf("%d", &uzivatelsky_vstup);  // Čte celočíselný vstup zadaný uživatelem a ukládá ho do proměnné uzivatelsky_vstup.
                                       // Formátovací řetězec "%d" říká funkci scanf, že očekává celočíselný vstup.
                                       // &uzivatelsky_vstup je adresa proměnné, kde bude vstup uložen.

    printf("Vysledek: %d\n", uzivatelsky_vstup * 2);  // Vypisuje text "Vysledek: " následovaný hodnotou proměnné uzivatelsky_vstup, vynásobenou dvěma.
                                                     // Výsledkem je číslo, které je dvakrát větší než zadané číslo.

    return 0;  // Ukončuje funkci main a vrací hodnotu 0, což obvykle znamená, že program proběhl bez problémů.
}
