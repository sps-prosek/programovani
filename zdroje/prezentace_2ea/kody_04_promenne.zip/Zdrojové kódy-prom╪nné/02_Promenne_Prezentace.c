/*---- | 04 PROMĚNNÉ A DATOVÉ TYPY V C | ----
==============================================
Zdrojový kód: 02_Promenne_Prezentace
*/

#include <stdio.h>  // Zahrnujeme standardní knihovnu pro vstup a výstup, která umožňuje používání funkcí jako printf.

#define KONSTANTA 10  // Definujeme makro s názvem KONSTANTA a přiřazujeme mu hodnotu 10. Tento kód bude nahrazen hodnotou 10 během kompilace.

int main()  // Začátek hlavní funkce programu. Program začne svůj běh zde.
{
    // Funkce printf slouží k vypsání textu na obrazovku.
    // Používáme formátovací řetězec "%d", který se používá pro zobrazení celočíselných hodnot.
    // KONSTANTA je nahrazena hodnotou 10, takže printf vypíše číslo 10.
    printf("%d", KONSTANTA);  // Vypíše hodnotu makra KONSTANTA, což je 10.
    
    return 0;  // Vrací hodnotu 0, což znamená, že program skončil úspěšně.
}