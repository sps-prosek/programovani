/*---- | 04 PROMĚNNÉ A DATOVÉ TYPY V C | ----
==============================================
Zdrojový kód: 03_Promenne_Prezentace
*/

#include <stdio.h>  // Zahrnujeme standardní knihovnu pro vstup a výstup, která poskytuje funkce jako printf.

const int konstanta = 10;  // Deklarujeme proměnnou typu int (celé číslo) s názvem konstanta a přiřazujeme jí hodnotu 10.
                          // Klíčové slovo 'const' znamená, že hodnotu této proměnné nelze měnit po jejím inicializování.

int main()  // Začátek hlavní funkce programu. Program začne svůj běh zde.
{
    // Funkce printf slouží k vypsání textu na obrazovku.
    // Používáme formátovací řetězec "%d", který slouží pro zobrazení celočíselných hodnot.
    // V tomto případě vypisujeme hodnotu proměnné konstanta.
    printf("%d", konstanta);  // Vypíše hodnotu proměnné konstanta, což je 10.
    
    return 0;  // Vrací hodnotu 0, což signalizuje, že program skončil úspěšně.
}
