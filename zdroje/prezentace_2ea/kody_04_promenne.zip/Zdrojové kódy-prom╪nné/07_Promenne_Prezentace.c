/*---- | 04 PROMĚNNÉ A DATOVÉ TYPY V C | ----
==============================================
Zdrojový kód: 07_Promenne_Prezentace
*/

#include <stdio.h>  // Zahrnujeme standardní knihovnu pro vstup a výstup. Tato knihovna poskytuje funkce jako printf (pro výstup na obrazovku) a scanf (pro čtení vstupu od uživatele).

int main()  // Hlavní funkce programu, kde začíná vykonávání programu.
{
    float x, y;  // Deklarujeme dvě proměnné typu float (desetinné číslo) s názvy x a y. Tyto proměnné budou uchovávat desetinné hodnoty zadané uživatelem.

    printf("Zadejte dve cisla: \n");  // Vypisuje na obrazovku zprávu, která vyzývá uživatele, aby zadal dvě čísla.

    scanf("%f%f", &x, &y);  // Čte dvě desetinné hodnoty zadané uživatelem a ukládá je do proměnných x a y.
                             // Formátovací řetězec "%f%f" říká funkci scanf, že očekává dva desetinné vstupy.
                             // &x a &y jsou adresy proměnných, kam budou vstupy uloženy.

    printf("Soucet: %.2f\n", x + y);  // Vypisuje text "Soucet: " následovaný součtem hodnot proměnné x a y.
                                      // Formátovací řetězec "%.2f" zajišťuje, že výstup bude zobrazen s přesností na dvě desetinná místa.

    printf("Rozdil: %.2f\n", x - y);  // Vypisuje text "Rozdil: " následovaný rozdílem hodnot proměnné x a y.
                                      // Výstup je formátován na dvě desetinná místa.

    printf("Soucin: %.2f\n", x * y);  // Vypisuje text "Soucin: " následovaný součinem hodnot proměnné x a y.
                                      // Výstup je formátován na dvě desetinná místa.

    printf("Podil: %.2f\n", x / y);  // Vypisuje text "Podil: " následovaný podílem hodnot proměnné x a y.
                                     // Výstup je formátován na dvě desetinná místa.
                                     // Poznámka: Je dobré přidat kontrolu na dělení nulou, aby se předešlo chybám, ale v tomto kódu není zahrnuto.

    return 0;  // Ukončuje funkci main a vrací hodnotu 0, což obvykle znamená, že program skončil úspěšně.
}

