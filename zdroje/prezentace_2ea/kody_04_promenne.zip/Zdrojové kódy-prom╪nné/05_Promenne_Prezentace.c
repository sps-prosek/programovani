/*---- | 04 PROMĚNNÉ A DATOVÉ TYPY V C | ----
==============================================
Zdrojový kód: 05_Promenne_Prezentace
*/

#include <stdio.h>  // Zahrnujeme standardní knihovnu pro vstup a výstup. Tato knihovna poskytuje funkce jako printf (pro výstup na obrazovku) a scanf (pro čtení vstupu od uživatele).

int main()  // Hlavní funkce programu. Program začne běžet zde.
{
    int x, y, z;  // Deklarujeme tři proměnné typu int (celé číslo) s názvy x, y a z. Tyto proměnné budou uchovávat čísla zadaná uživatelem.
    double prumer;  // Deklarujeme proměnnou typu double (desetinné číslo) s názvem prumer. Tato proměnná bude uchovávat průměr zadaných čísel.

    printf("Vlozte cisla: \n");  // Vypisuje zprávu na obrazovku, která vyzývá uživatele k zadání tří čísel.

    scanf("%d%d%d", &x, &y, &z);  // Čte tři celočíselné hodnoty zadané uživatelem a ukládá je do proměnných x, y a z.
                                    // Formátovací řetězec "%d%d%d" říká funkci scanf, že očekává tři celočíselné vstupy.
                                    // &x, &y a &z jsou adresy proměnných, kam budou vstupy uloženy.

    prumer = (x + y + z) / 3.0;  // Vypočítá průměr z tří čísel. Používáme 3.0 místo 3 pro zajištění, že dělení probíhá s desetinnými čísly (typ double),
                                  // což zajistí přesný výsledek. Výsledný průměr bude uložen v proměnné prumer.

    printf("Prumer: %.2lf\n", prumer);  // Vypisuje text "Prumer: " následovaný hodnotou proměnné prumer.
                                        // Formátovací řetězec "%.2lf" zajišťuje, že výstup bude zobrazen s přesností na dvě desetinná místa.

    return 0;  // Ukončuje funkci main a vrací hodnotu 0, což obvykle znamená, že program skončil úspěšně.
}


