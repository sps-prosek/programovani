/*---- | 04 PROMĚNNÉ A DATOVÉ TYPY V C | ----
==============================================
Zdrojový kód: 01_Promenne_Prezentace
*/

#include <stdio.h>  // Zahrnujeme standardní knihovnu pro vstup a výstup, která nám umožňuje používat funkci printf.

float x = 2.1f;  // Deklarujeme proměnnou typu float (desetinné číslo) s názvem x a inicializujeme ji hodnotou 2.1.
float y = 5.6f;  // Deklarujeme další proměnnou typu float s názvem y a inicializujeme ji hodnotou 5.6.

int main()  // Začátek hlavní funkce programu. Program začne svůj běh zde.
{
    // Funkce printf slouží k vypsání textu na obrazovku.
    // Používáme formátovací řetězec "%.2f", což znamená, že chceme zobrazit číslo s desetinnou tečkou a dvěma desetinnými místy.
    // x + y spočítá součet hodnot proměnných x a y.
    printf("Vysledek je: %.2f", x + y);  // Vypíše text "Vysledek je:" následovaný výsledkem součtu x a y (2.1 + 5.6) ve formátu s dvěma desetinnými místy.
    
    return 0;  // Vrací hodnotu 0, což znamená, že program skončil úspěšně.
}
