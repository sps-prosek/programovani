/*---- | 04 PROMĚNNÉ A DATOVÉ TYPY V C | ----
==============================================
Zdrojový kód: 04_Promenne_Prezentace
*/

#include <stdio.h>  // Zahrnujeme standardní knihovnu pro vstup a výstup, která poskytuje funkce jako printf a scanf.

int main()  // Začátek hlavní funkce programu. Program začne svůj běh zde.
{
    int x;  // Deklarujeme proměnnou typu int (celé číslo) s názvem x. Tato proměnná bude sloužit k uchování čísla zadaného uživatelem.

    printf("Vlozte cislo: \n");  // Vypisuje na obrazovku text "Vlozte cislo: ". Tento text vyzývá uživatele, aby zadal číslo.

    scanf("%d", &x);  // Čte celé číslo zadané uživatelem a uloží ho do proměnné x.
                      // Formátovací řetězec "%d" říká funkci scanf, že očekává celočíselný vstup.
                      // &x je adresa proměnné x, kde bude číslo uloženo.

    printf("Zadane cislo: %d\n", x);  // Vypisuje na obrazovku text "Zadane cislo: " následovaný hodnotou proměnné x.
                                      // Formátovací řetězec "%d" se používá pro zobrazení celočíselné hodnoty.

    return 0;  // Vrací hodnotu 0, což signalizuje, že program skončil úspěšně.
}

